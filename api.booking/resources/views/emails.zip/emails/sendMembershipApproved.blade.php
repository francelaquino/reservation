<html>
<head></head>
<body style='font-family:arial'>
<h4>Hello <?php echo $name; ?></h4>
<h3>Congratulations</h3>
<p>Your Membership and loan applacation has been approved</p>
<p>Your member id is : <?php echo $username; ?></p>
<p>Please click <a href="http://account.payrollclub.co/#/memberlogin">here</a> to login</p>

<h3>Thank You!</h3>
</body>
</html>