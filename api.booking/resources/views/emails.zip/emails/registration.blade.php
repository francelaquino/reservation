<html>
<head>
</head>
<body style="font-family: arial">
<p>Dear <?php echo $name; ?> </p>
<h4>Thank you for signing up an account.</h4>
<p>To get started  in  booking please login your account at www.uniserb.com.</p>
<h4>Thank you.</h4>
<h5>Universal Search Buddy (UNISERB) -  ADMIN</h5>
<p style="font-size:10px;color:gray">* This is a system generated email. Please do not reply</p>
</body>
</html>