<html>
<head></head>
<body style='font-family:arial'>
<h4>Dear Partner/<?php echo $username; ?> </h4>
<p>Your password was changed on <?php echo date("F j, Y, g:i a"); ?></p>
<p>If you made this change, you don't need to do anything. You can use your password the next time you log in.</p>
<p>If you didn't change your password, please contact support@payrollclub.co</p>

<p>Please do not reply to this email.</p>
<h3>Thank You!</h3>

</body>
</html>