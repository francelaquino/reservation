<html>
<head></head>
<body style='font-family:arial'>
<h4>Dear Admin </h4>
<p>Member requested a salary advance needs your approval</p>
<p>This will send after the partner verify or approved the net pay</p>
<h3>Thank You!</h3>
</body>
</html>