<html>
<head>

</head>
<body style="font-family: arial">

<p>Dear : <?php echo $name; ?></p>


<p>This is to inform you that  you successful added your property name <?php echo $property; ?>.</p>
<p>Please wait for  24 hour for approval of your listing.  </p>
<p>After you receive the confirmation. Please login  as property owner and go to  registered LIST OF PROPERTY  and click the POST property </p>
<p>Thank you.</p>
<h5>Universal Search Buddy (UNISERB) - ADMIN</h5>

<p style="font-size:10px;color:gray">* This is a system generated email. Please do not reply</p>

</body>
</html>