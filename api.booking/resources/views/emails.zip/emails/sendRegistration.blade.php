<html>
<head></head>
<body style='font-family:arial'>
<h4>Hello <?php echo $name; ?></h4>
<h3>Welcome to PayrollClub!</h3>
<p>You registration and loan application has been submitted and waiting for approval</p>
<p>Approval process shall take 1-2 business days.</p>


<h3>Thank You!</h3>
</body>
</html>