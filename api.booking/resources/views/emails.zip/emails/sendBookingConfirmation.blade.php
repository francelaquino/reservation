<html>
<head>

</head>
<body style="font-family: arial">

<p>Dear : <?php echo $name; ?></p>



<p>Your booking is successfully created.</p>
<p>Property : <?php echo $property; ?></p>
<p>If you pay using Paypal, we will send a confirmation  message in your email regarding with your booking within 24 hours.</p>
<p>If you pay thru bank transfer: Please send to us your payment reference number.  If you  pay thru bank please send the deposit  slip @ <?php echo $owneremail; ?>.</p>
<p>We will confirm your booking upon receiving your payment in our bank  paypal / bank account. </p>
<p>If  we did not received your  payment  within 48 hours, your booking will be cancel. </p>
<p>Thank you.</p>
<h5>Universal Search Buddy (UNISERB) - ADMIN</h5>

<p style="font-size:10px;color:gray">* This is a system generated email. Please do not reply</p>

</body>
</html>