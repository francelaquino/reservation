<html>
<head>
		<style type="text/css">
		p{
			margin-bottom: 5px;
			font-size: 13px;
		}
		
	</style>
</head>
<body style='font-family:arial'>
<h4>Dear Partner,</h4>
<p>You recently request your account details</p>
<p>Username : <?php echo $username; ?></p>
<p>&nbsp;</p>
<p>If you wish to reset your password click below</p>
<a href='<?php echo $link; ?>'><h2>Password Reset</h2></a>
<p>If the above does not work, please copy and paste the one below into your browser</p>
<p><?php echo $link; ?></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h3>Payroll Club Team</h3>
<p style="font-size: :8px;color:gray">* This is a system generated email. Please do not reply</p>
<p style="font-size: :8px;color:gray">Payroll Club - Confidential Communication
This e-mail message including any of its attachments is intended solely for the addressee(s) and may contain privileged information. If you are not the addressee or you have received this email message in error. Please notify the sender and delete the email destroying any hard copies of the original e-mail message and The sender will remove your details from its database. You are not authorised to read, copy, disseminate, distribute or use this e-mail message or any attachment to it in any manner.</p>
</body>
</html>