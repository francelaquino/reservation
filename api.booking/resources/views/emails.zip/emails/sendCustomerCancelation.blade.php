<html>
<head>

</head>
<body style="font-family: arial">

<p>Dear : Client</p>



<p>This is to inform you that  we receive your request to cancel your booking.</p>
<p>Thank you.</p>
<h5>Universal Search Buddy (UNISERB) - ADMIN</h5>

<p style="font-size:10px;color:gray">* This is a system generated email. Please do not reply</p>

</body>
</html>