<html>
<head></head>
<body style='font-family:arial'>
<h4>Dear Partner </h4>
<h3>Your account pasword has been reset.</h3>
<p>Username : <b><?php echo $username; ?></b></p>
<p>Password : <b><?php echo $password; ?></b></p>
<p style="color:red">After you log in, you will be required to change your password.</p>
<p>Please <a href='http://localhost/accounts.payrollclub/#/partnerlogin'>here</a>
or copy the following URL  into your browser to get started : <a href='http://localhost/accounts.payrollclub/#/partnerlogin'>http://localhost/accounts.payrollclub/#/partnerlogin</a></p>

<h3>Thank You!</h3>
</body>
</html>